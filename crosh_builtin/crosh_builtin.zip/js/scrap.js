/*
  1/11/111 -> 1102/1102/1102
  a/aa/aaa -> aab4/aab4/aab4
  3/33/333 -> 3326/3326/3326
       3333 -> 3326

  12/12/1212 -> 1202/1202/1202

  46/4646/b4b4 -> 4648/4648/b4b5

  464/646/b4b -> 4648/646c/b4b5
  460/46f/46ff -> 4648/4748/4748

  ab/aa/aaa -> aab4

  01/010/011 -> 0100/0100/0100

  0f/0ff/0fff -> 0f01/1001/1001

  0f/00f/00ff -> 0f01/1001/1001

  f/0ff/0fff -> ffff/1001/1001

 */


/**
 * Insert a single node at the current cursor position.
 *
 * This checks the cursor node (and sometimes the node before or after the
 * cursor node) to see if it's possible to merge the two nodes.
 */
hterm.Screen.prototype.insert = function(obj) {
  var cursorNode = this.cursorNode_;
  var cursorNodeText = cursorNode.textContent;

  // Reverse offset is the offset measured from the end of the string.
  // Zero implies that the cursor is at the end of the cursor node.
  var reverseOffset = cursorNodeText.length - this.cursorOffset_;

  var targetNode;

  if (hterm.TextAttributes.containersMatch(obj, cursorNode)) {
    // We match the cursor node, it's all good.
    targetNode = cursorNode;

  } else if (reverseOffset <= 0) {
    // Cursor is at the end of the cursorNode.
    var nextSibling = cursorNode.nextSibling;
    if (nextSibling &&
        this.textAttributes.matchesContainer(cursorNode)) {
      // If following node is a match, we'll prepend there.
      targetNode = nextSibling;
    } else {
      // Otherwise we need to create a new container.
      targetNode = this.textAttributes.createContainer();
      this.cursorRowNode_.insertBefore(targetNode, nextSibling);
    }

  } else if (this.cursorOffset_ == 0) {
    // Cursor is at the beginning of the cursorNode.
    var nextSibling = this.cursorNode_.nextSibling;
    if (nextSibling &&
        this.textAttributes.matchesContainer(this.cursorNode_)) {
      targetNode = nextSibling;
    }
  }

  if (!targetNode) {
  }

  if (reverseOffset < 0) {
    // A negative reverseIndex means the cursor is beyond the end of the
    // node.  This happens if the cursor is positioned beyond the last
    // character on the line.  In that case we have to insert the missing
    // spaces before the new node.
    var ws = hterm.getWhitespace(-reverseOffset);

    if (cursorNode.nodeType == 3 || !cursorNode.style.textDecoration) {
      // If the cursor node has the default attributes, or has no text
      // decoration, we can just insert the spaces in it.
      cursorNode.textContent = (cursorNodeText += ws);
    } else {
      // Otherwise the textDecoration (which is used for underline) would
      // show for these spaces, and we don't want that.  Instead we have to
      // create a new text node to hold the missing spaces.
      cursorNode = cursorNode.ownerDocument.createTextNode(ws);
      this.cursorRowNode_.insertBefore(cursorNode,
                                       this.cursorNode_.nextSibling);
      this.cursorNode_ = cursorNode;
      this.cursorOffset_ = -reverseOffset;
      cursorNodeText = ws;
    }

    // We know for sure we're at the end of the string.
    reverseOffset = 0;
  }

  var containersMatch = hterm.TextAttributes.containersMatch(cursorNode, node);

  if (!containersMatch) {
    if (reverseOffset == 0) {
      // We're at the end of this container, maybe the next matches.
      var nextSibling = cursorNode.nextSibling;
      if (nextSibling &&
          hterm.TextAttributes.containersMatch(nextSibling, node)) {
        this.cursorNode_ = cursorNode = nextSibling;
        cursorNodeText = cursorNode.textContent;
        this.cursorOffset_ = 0;
        reverseOffset = cursorNodeText.length;
        containersMatch = true;
      }
    } else if (this.cursorOffset_ == 0) {
      // We're at the beginning of this container, maybe the previous matches.
      var previousSibling = cursorNode.previousSibling;
      if (previousSibling &&
          hterm.TextAttributes.containersMatch(previousSibling, node)) {
        this.cursorNode_ = cursorNode = previousSibling;
        cursorNodeText = cursorNode.textContent;
        this.cursorOffset_ = cursorNodeText.length;
        reverseOffset = 0;
        containersMatch = true;
      }
    }
  }

  if (containersMatch) {
    var newText = node.textContent;

    if (this.cursorOffset_ == 0) {
      cursorNode.textContent = newText + cursorNodeText;
    } else if (reverseOffset == 0) {
      cursorNode.textContent = cursorNodeText + newText;
    } else {
      cursorNode.textContent = cursorNodeText.substr(0, this.cursorOffset_) +
          newText + cursorNodeText.substr(this.cursorOffset_);
    }

    this.cursorOffset_ += newText.length;
    this.cursorPosition.column += newText.length;
  } else {
    if (this.cursorOffset_ == 0) {
      this.cursorRowNode_.insertBefore(node, this.cursorNode_);
    } else if (reverseOffset == 0) {
      this.cursorRowNode_.insertBefore(node, this.cursorNode_.nextSibling);
    } else {
      this.splitNode_(this.cursorNode_, this.cursorOffset_);
      this.cursorRowNode_.insertBefore(node, this.cursorNode_.nextSibling);
    }

    this.cursorNode_ = node;
    this.cursorOffset_ = node.textContent.length;
    this.cursorPosition.column += this.cursorOffset_;
  }
};

hterm.Screen.prototype.insertString = function(str) {
  var cursorNode = this.cursorNode_;
  var cursorNodeText = cursorNode.textContent;

  var reverseOffset = cursorNodeText.length - this.cursorOffset_;
  if (reverseOffset < 0) {
    var ws = hterm.getWhitespace(-reverseOffset);
    if (cursorNode.nodeType == 3 || !cursorNode.style.textDecoration) {
      cursorNode.textContent = (cursorNodeText += ws);
    } else {
      cursorNode = cursorNode.ownerDocument.createTextNode(ws);
      this.cursorRowNode_.insertBefore(cursorNode,
                                       this.cursorNode_.nextSibling);
      this.cursorNode_ = cursorNode;
      this.cursorOffset_ = -reverseOffset;
      cursorNodeText = ws;
    }
    reverseOffset = 0;
  }

  var containersMatch = this.textAttributes.matchesContainer(cursorNode);

  if (!containersMatch) {
    if (reverseOffset == 0) {
      // We're at the end of this container, maybe the next matches.
      var nextSibling = cursorNode.nextSibling;
      if (nextSibling &&
          this.textAttributes.matchesContainer(nextSibling)) {
        this.cursorNode_ = cursorNode = nextSibling;
        cursorNodeText = cursorNode.textContent;
        this.cursorOffset_ = 0;
        reverseOffset = 0;
        containersMatch = true;
      }
    }

    if (!containersMatch && this.cursorOffset_ == 0) {
      // We're at the beginning of this container, maybe the previous matches.
      var previousSibling = cursorNode.previousSibling;
      if (previousSibling &&
          this.textAttributes.matchesContainer(previousSibling)) {
        this.cursorNode_ = cursorNode = previousSibling;
        cursorNodeText = cursorNode.textContent;
        this.cursorOffset_ = cursorNodeText.length;
        reverseOffset = 0;
        containersMatch = true;
      }
    }
  }

  if (containersMatch) {
    if (this.cursorOffset_ == 0) {
      cursorNode.textContent = str + cursorNodeText;
    } else if (reverseOffset == 0) {
      cursorNode.textContent = cursorNodeText + str;
    } else {
      cursorNode.textContent = cursorNodeText.substr(0, this.cursorOffset_) +
          str + cursorNodeText.substr(this.cursorOffset_);
    }

    this.cursorOffset_ += str.length;
    this.cursorPosition.column += str.length;
  } else {
    var node = this.textAttributes.createContainer(str);

    if (this.cursorOffset_ == 0) {
      this.cursorRowNode_.insertBefore(node, this.cursorNode_);
    } else if (reverseOffset == 0) {
      this.cursorRowNode_.insertBefore(node, this.cursorNode_.nextSibling);
    } else {
      this.splitNode_(this.cursorNode_, this.cursorOffset_);
      this.cursorRowNode_.insertBefore(node, this.cursorNode_.nextSibling);
    }

    this.cursorNode_ = node;
    this.cursorOffset_ = str.length;
    this.cursorPosition.column += str.length;
  }
};


/**
 * Insert a string at the current cursor position.
 *
 * If the insert causes the column to overflow, the extra text is returned.
 * If only the cursor overflows (ie, you print exactly enough to fill the
 * last column) then the empty string is returned.
 *
 * @return {string} Text that overflowed the column, or null if nothing
 *     overflowed.
 */
hterm.Screen.prototype.__insertString = function(str) {
  if (this.cursorPosition.column == this.columnCount_)
    return str;

  var totalRowText = this.cursorRowNode_.textContent;
  var insertCount = str.length;

  // There may not be underlying characters to support the current cursor
  // position since they don't get inserted until they're necessary.
  var missingSpaceCount = Math.max(this.cursorPosition.column -
                                   totalRowText.length,
                                   0);
  if (missingSpaceCount) {
    var ws = hterm.getWhitespace(missingSpaceCount);
    this.cursorRowNode_.lastChild.textContent += ws;
    totalRowText += ws;
  }

  if (!this.textAttributes.matchesContainer(this.cursorNode_)) {
    this.splitNode_(this.cursorNode_, this.cursorOffset_);
    var container = this.textAttributes.createContainer();
    container.textContent = str;
    this.cursorRowNode_.insertBefore(container, this.cursorNode_.nextSibling);
    this.cursorNode_ = container;
    this.cursorOffset_ = insertCount;
  } else {
    var text = this.cursorNode_.textContent;
    this.cursorNode_.textContent = text.substr(0, this.cursorOffset_) +
        str + text.substr(this.cursorOffset_);
    this.cursorOffset_ += insertCount;
  }

  this.cursorPosition.column += insertCount;

  if (totalRowText + insertCount > this.columnCount_) {
    var currentColumn = this.cursorPosition.column;
    this.setCursorPosition(this.cursorPosition.row, this.columnCount_);
    var overflow = this.clipAtCursor_();
    if (currentColumn < this.cursorPosition.column) {
      this.setCursorPosition(this.cursorPosition.row, currentColumn);
    } else if (currentColumn > this.columnCount_) {
      this.cursorPosition.overflow = true;
    }

    return overflow;
  }

  return null;
};



/**
 * Interpret a sequence of characters.
 *
 * Incomplete escape sequences are buffered until the next call.
 *
 * @param {string} str Sequence of characters to interpret or pass through.
 */
hterm.VT.prototype.XXX = function(str) {
  for (var i = 0; i < str.length; i++) {
    // Note that the SEQ_PLAINTEXT case below may advance the 'i' variable
    // to skip over a contiguous block of plain text.

    var ch = str.substr(i, 1);

    if (this.sequenceType_ == hterm.VT.SEQ_CONTROL ||
        hterm.VT.controlCharacterPattern.match(ch)) {
      this.interpretControlCharacter_(ch);

      if (this.sequenceType_ == hterm.VT.SEQ_CONTROL)
        this.sequenceType_ = hterm.VT.SEQ_PLAINTEXT;

      continue;
    }

    if (this.sequenceType_ == hterm.VT.SEQ_UNKNOWN) {
      // We read ESC on the last iteration, this character should tell us
      // what kind of escape we're dealing with.
      var type = this.getSequenceType_(ch);

      if (type == hterm.VT.SEQ_ANSI_IMMEDIATE) {
        // A no-parameter ANSI code, e.g., 'ESC E' (Next Line).
        this.dispatchSequence(hterm.VT.ANSI, ch, null);
        continue;
      }

      if (type == hterm.VT.SEQ_VT52 && ch != 'Y') {
        // A no-parameter VT52 code.  'Y' is the only VT52 code that has
        // parameters.
        this.dispatchSequence(hterm.VT.VT52, ch, null);
        continue;
      }

      if (type != hterm.VT.SEQ_PLAINTEXT) {
        // Any other recognized escape sequence.
        this.sequenceType_ = type;
        this.sequenceCode_ = ch;
        continue;
      }

      // Unrecognized sequence, print the ESC that started it, then fall
      // through to print the rest as plain text.
      this.terminal.print('\x1b');
    }

    if (this.sequenceType_ == hterm.VT.SEQ_PLAINTEXT) {
      // Search for the next contiguous block of plain text.
      var nextControl = str.substr(i).search(hterm.VT.controlCharacterPattern);

      if (nextControl == -1) {
        // If we hit the end of the string, eat it all.
        nextControl = str.length;
      } else {
        // Otherwise we know for sure the next character is a control
        // character.  Set the sequence type so we don't have to re-check it
        // at the top of the loop.
        this.sequenceType_ == hterm.VT.SEQ_CONTROL;
      }

      if (nextControl != 0) {
        this.terminal.print(str.substr(i, nextControl));
        // Skip over these characters (minus one to account for the loop
        // increment).
        i += nextControl - 1;
        continue;
      }

      // We shouldn't be able to get here.  This implies that the current
      // character is a control character, but if so it should have been
      // handled at the top of the loop.
      throw 'Unexpected control character: ' + JSON.stringify(ch);
    }

    if (this.sequenceType_ == hterm.VT.SEQ_ANSI_VARARGS) {
      var args = this.sequenceArgs_;
      if (args.length == 0 && hterm.VT.modifierPattern.test(ch)) {
        this.sequenceCode_ += ch;
        continue;
      }

      if (ch >= '0' && ch <= '9') {
        if (!args.length || typeof args[args.length - 1] == 'number') {
          // If we don't have arguments yet or we've already finished parsing
          // the previous argument then push this as a new argument.
          args.push(ch);
        } else {
          // Otherwise append it to the current pending argument.
          args[args.length - 1] += ch;
        }

        continue;
      }

      if (args.length) {
        // This character isn't a number, so the pending argument must be
        // done.  Convert it to an integer.
        args[args.length - 1] = parseInt(args[args.length - 1], 10);
      }

      if (ch == ';') {
        if (!args.length) {
          // The ';' character came before any arguments, which implies a first
          // argument of '0'.
          args.push(0);
        }

        continue;
      }

      // Character is not a number and not a parameter separator so it must
      // be the final character.
      this.dispatchSequence(hterm.VT.ANSI, this.sequenceCode_ + ch,
                            this.sequenceArguments_);
      continue;
    }

    if (this.sequenceType_ == hterm.VT.SEQ_VT52) {
      if (this.sequenceCode_ != 'Y')
        throw 'Unexpected VT52 sequence: ' + this.sequenceCode_;

      // The 'Y' command is the only VT52 sequence which takes parameters, and
      // there are always exactly two bytes of trailing parameters.
      if (this.sequenceArgs_.length != 2) {
        this.sequenceArgs_.push(ch);
        continue;
      }

      this.dispatchSequence(hterm.VT.VT52, this.sequenceCode_,
                            this.sequenceArguments_);
      continue;
    }

    if (this.sequenceType_ == hterm.VT.SEQ_ANSI_NOARGS) {
      this.dispatchSequence(hterm.VT.ANSI, this.sequenceCode_ + ch, null);
      continue;
    }
  }
};


/**
 * Interpret a control character.
 *
 * See <http://vt100.net/docs/vt100-ug/table3-10.html>. and
 * "C1 (8-Bit) Control Characters" in [XTERM].
 */
hterm.VT.prototype.interpretControlCharacter_ = function(ch) {
  switch (ch) {
    case '\x00':  // Octal 000, NUL
    case '\x7F':  // Octal 177, DEL
      break;

    case '\x07':  // Octal 007, BEL
      this.terminal.ringBell();
      break;

    case '\x08':  // Octal 010, BS
      this.terminal.cursorLeft(1);
      break;

    case '\x09':  // Octal 011, HT
      this.terminal.nextTabStop();
      break;

    case '\x0A':  // Octal 012, LF
      this.terminal.newLine();
      break;

    case '\x0B':  // Octal 013, VT
    case '\x0C':  // Octal 014, FF
      this.terminal.formFeed();
      break;

    case '\x0D':  // Octal 015, CR
      this.terminal.setCursorColumn(0);
      break;

    case '\x0E': // Octal 016, SO
      this.terminal.setCharacterSet(1);
      break;

    case '\x0F': // Octal 017, SI
      this.terminal.setCharacterSet(0);
      break;

    case '\x11': // Octal 021, XON
      this.terminal.xon();
      break;

    case '\x13': // Octal 023, SOFF
      this.terminal.xoff();
      break;

    case '\x18': // Octal 030, CAN
    case '\x1A': // Octal 032, SUB
      this.sequenceType_ = hterm.VT.SEQ_PLAINTEXT;
      break;

    case '\x1B': // Octal 033, ESC
      this.sequenceType_ = hterm.VT.SEQ_UNKNOWN;
      this.sequenceCode_ = null;
      this.sequenceArguments_.length = 0;
      break;

    default:
      // This should never happen, since we only invoke this function when we
      // know the character is one of the above.
      throw 'Unknown control character: ' + JSON.stringify(character);
  }
};

/**
 * Characters which can appear after 'ESC [' but before the argument list
 * to modifiy the meaning of the escape sequence.
 */
hterm.VT.controlCharacter.modifierPattern = /[?+$>!]/;

/**
 * List of ANSI-mode escape codes that are not prefixed by '['.
 *
 * See "Controls beginning with ESC" in [XTERM].
 *
 * These characters trigger SEQ_ANSI_IMMEDIATE.
 */
hterm.VT.ansiImmediatePattern = /[6789cDEHZ=>]/;

/**
 * List of ANSI-mode escape codes that have no arguments.
 *
 * See "Controls beginning with ESC" in [XTERM].
 *
 * These characters trigger SEQ_ANSI_NOARGS.
 */
hterm.VT.ansiNoArgsPattern = /[\s#%()*+-.\/]/;

/**
 * List of VT52 mode escapes.
 *
 * See "Valid VT52 Mode Control Sequences" in [VT100].
 *
 * These characters trigger SEQ_VT52 when in VT52 mode.
 */
hterm.VT.vt52Pattern = /[ABCDFGHIJKYZ=<>]/;


hterm.VT.prototype.dispatchSequence_ = function(collection, code, args) {
  if (code in collection) {
    collection[code].apply(this, [args]);
  } else {
    console.error('Unrecognized ' + collection.name + ' escape: ' + code);
  }

  this.sequenceType_ = hterm.VT.SEQ_PLAINTEXT;
};

hterm.VT.prototype.getSequenceType_ = function(ch) {
  if (this.isVT52Mode) {
    if (hterm.VT.vt52Pattern.test(ch))
      return hterm.VT.SEQ_VT52;

  } else {
    if (ch == '[')
      return hterm.VT.SEQ_ANSI_VARARGS;

    if (ch == '#' || ch == '(' || ch == ')')
      return hterm.VT.SEQ_ANSI_NOARGS;

    if (hterm.VT.ansiImmediatePattern.test(ch))
      return hterm.VT.SEQ_ANSI_IMMEDIATE;
  }

  // Did not recognize the sequence, fall back to plain text.
  return hterm.VT.SEQ_PLAINTEXT;
};

hterm.VT.CC1List = hterm.VT.CC1.keys().sort();

hterm.VT.isControlCharacter = function(ch) {
  var list = hterm.VT.CC1List;
  var above = 0;
  var below = list.length - 1;
  var i = max;

  while (true) {
    if (ch == list[i])
      return true;

    if (ch > list[i]) {
      above = i;
      i = Math.floor((below - above) / 2);
    } else if (ch < list[i]) {
      below = i;
      i = Math.floor((below - above) / 2);
    }
