// Copyright (c) 2012 The Chromium OS Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

hterm.PreferenceManager.Tests = new TestManager.Suite(
    'hterm.PreferenceManager.Tests');

hterm.PreferenceManager.Tests.prototype.setup = function(cx) {
  this.setDefaults(cx,
      { visibleColumnCount: 15,
        visibleRowCount: 6,
        fontSize: 15,
        lineHeight: 17,
        charWidth: 9,
        scrollbarWidth: 16,
      });
};
